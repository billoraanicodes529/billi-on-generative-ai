from transformers import pipeline
qa_model=pipeline("question-answering")

context=input("Enter Paragraph: ")

que=input("Enter the Quetion")

result=qa_model(question=que, context=context)
print("Answer:", result["answer"])
