from transformers import pipeline
gc=pipeline("text2text-generation",model="grammarly/coedit-large")
sentence=input("Enter a sentence to correct grammar: ")
corrected=gc(sentence)[0]['generated_text']
print("\nOriginal Sentence: ", sentence)
print("\nCorrected Sentence: ",corrected)
