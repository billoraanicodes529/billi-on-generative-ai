from transformers import pipeline
sa = pipeline("sentiment-analysis")
sentences=[
    "The movie was amazing and inspiring!",
    "I did not like the food at the restaurant.",
    "The weather today is okay."
]
result= sa(sentences)
for i, result in enumerate(result):
    print(f"Sentence: {sentences[i]}")
    print(f"Sentiment: {result['label']}")
    print(round(result['score'],3))
    print()