from transformers import pipeline
fill_mask=pipeline("fill-mask",model="bert-base-uncased")
text="Artificial Intelligence is an emerging[MASK]."
output=fill_mask(text)
print("BERT Fill-Mask Prediction:\n")
for pred in output:
    print(pred["token_str"],"->",pred["score"])