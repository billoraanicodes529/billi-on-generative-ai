from transformers import pipeline
sentiment = pipeline("sentiment-analysis")
text="I Love using AI tools, they area amazing!"
result= sentiment(text)
print(result)

