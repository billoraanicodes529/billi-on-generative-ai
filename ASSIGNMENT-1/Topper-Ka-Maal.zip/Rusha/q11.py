from transformers import pipeline
translator=pipeline("translation",model="Helsinki-NLP/opus-mt-en-mr")
text=input("Enter text in English: ")
result=translator(text)
print("Translated Text(Marathi): ",result[0]['translation_text'])