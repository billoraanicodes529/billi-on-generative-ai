from transformers import pipeline
sentiment = pipeline("sentiment-analysis")
text=input("Enter Sentence: ")
result= sentiment(text)
print(result)

