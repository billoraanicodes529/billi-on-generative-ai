from diffusers import StableDiffusionPipeline
import torch
pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
pipe = pipe.to("cpu")
prompt = input("Enter image prompt: ")

image = pipe(prompt).images[0]

image.save("output.png")

print("Image generated successfully!")