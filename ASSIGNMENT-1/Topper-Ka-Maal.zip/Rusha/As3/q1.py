from transformers import pipeline
generator=pipeline (
    "text2text-generation",
    model="google/flan-t5-large"
)
prompt="Write in one sentence Birthday greeting."
result=generator(prompt,max_length=30)
print("Greeting Message:")
print(result[0]["generated_text"])