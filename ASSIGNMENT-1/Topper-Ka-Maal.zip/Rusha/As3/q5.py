from transformers import pipeline

# Load text generation model
model = pipeline("text-generation", model="microsoft/Phi-3-mini-4k-instruct")

# Few-shot prompt with examples
prompt = """
Q: What is 2 + 3?
A: 5
Q: What is 4 + 6?
A: 10
Q: What is 7 + 8?
A:
"""

# Generate output
result = model(prompt, max_new_tokens=20)

# Print generated answer
print(result[0]["generated_text"])
