from transformers import pipeline
model=pipeline("text-generation")
output=model("Hello, I am learning LLM!", max_length=30)
print(output[0]["generated_text"])
