from transformers import pipeline
qa_model=pipeline("question-answering")

context="""The Sun is the center of owr solar system. 
It is a huge ball of hot gases.
Earth revolve around the sun in 365 days."""

que="how many days does earth take to revolve around the sun ?"

result=qa_model(question=que, context=context)
print("Answer:", result["answer"])
