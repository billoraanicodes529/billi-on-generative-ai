text="""Generative AI create new content such as text and images.
It learns patterns from data. It is used in chatbots and image creation tools. """
sentences=text.split(".")
summary=sentences[0]+"."+sentences[1]+"."
print("Summary:",summary)